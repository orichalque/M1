package com.TPWebNCloud;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.googlecode.objectify.ObjectifyService;

@SuppressWarnings("serial")
public class listPetitionServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			  throws ServletException, IOException {
		response.setContentType("text/plain");
		response.getWriter().println("Hello, world");
		
		List<Petition> liste = ObjectifyService.ofy().load().type(Petition.class).list();
		int i = 1;
		for (Petition p : liste) {
			response.getWriter().println("<li>"+i+" :"+p.toString()+"</li>");
		}
	}
} 