/*
 * Created on 23 oct. 06
 *
 */
package fr.univnantes.cta;

public class AirplaneOverload extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = -8657209228880446964L;

    public AirplaneOverload() {
        super("Airplane Overload");
    }
}
