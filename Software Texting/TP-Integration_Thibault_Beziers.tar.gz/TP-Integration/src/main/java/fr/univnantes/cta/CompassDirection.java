/*
 * Created on 22 oct. 06
 *
 */
package fr.univnantes.cta;

public enum CompassDirection {
    NORTH, SOUTH, EAST, WEST;
}
