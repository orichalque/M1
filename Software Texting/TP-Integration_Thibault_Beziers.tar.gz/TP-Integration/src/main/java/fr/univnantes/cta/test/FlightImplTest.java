package fr.univnantes.cta.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class FlightImplTest {

	@Before
	public void setUp() throws Exception {
		System.out.println("Inutile, classe abstraite. Les méthodes sont testées dans CreateCivilFlight & createMilitarFlight");
	}

	@After
	public void tearDown() throws Exception {
	}
}
