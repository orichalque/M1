
/* 
 * File:   Polynome.cpp
 * Author: E104607D
 * 
 * Created on 28 septembre 2015, 16:16
 */

#include "Polynome.h"
/*
Polynome::Polynome() {
}

virtual Polynome::~Polynome() {
}
  */

virtual void Polynome::fill(int degree) {
}

virtual int Polynome::resolve(int unknown) {
}

virtual void Polynome::toString() {
}