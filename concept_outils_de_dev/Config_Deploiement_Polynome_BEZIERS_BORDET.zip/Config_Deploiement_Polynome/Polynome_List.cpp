/* 
 * File:   Polynome_List.cpp
 * Author: E104607D
 * 
 * Created on 28 septembre 2015, 16:15
 */

#include "Polynome_List.h"
using namespace std;

Polynome_List::Polynome_List() {
    int coef;
    cout << "Entrez le coef" << endl;
    cin >> coef;
    coefs.push_back(coef);
    size = 0;
}

Polynome_List::Polynome_List(int degree) {
    size = degree;
    int coef;
    for (int i = 0; i <= degree; ++i) {
        cout << "Coefficient de x^"<<(degree-i) << endl; 
        cin >> coef;
        coefs.push_back(coef);
    }
}

Polynome_List::Polynome_List(const Polynome_List& orig) {
}

Polynome_List::~Polynome_List() {
}

void Polynome_List::fill(int degree) {
    coefs.clear();
    size = degree;
    int coef;
    for (int i = 0; i <= degree; ++i) {
        cout << "Coefficient de x^"<<(degree-i) << endl; 
        cin >> coef;
        coefs.push_back(coef);
    }
}

int Polynome_List::resolve(int unknown) {
    list<int>::iterator i;
    if (size == 0) {
        return *coefs.begin();
    } 
    
    int result =  *coefs.begin()*unknown + *(coefs.begin()++);
    if (size == 1) return result;
    
    i = coefs.begin();
    i++; i++;
    while (i != coefs.end()){
        result = result*unknown + *i;
        ++i;
    }
    return result;
}

void Polynome_List::toString(void){
    
}
