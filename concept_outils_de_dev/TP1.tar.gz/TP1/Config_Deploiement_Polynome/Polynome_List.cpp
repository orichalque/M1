/* 
 * File:   Polynome_List.cpp
 * Author: E104607D
 * 
 * Created on 28 septembre 2015, 16:15
 */

#include "Polynome_List.h"


Polynome_List::Polynome_List() {
}

Polynome_List::Polynome_List(int degree) {
}

Polynome_List::Polynome_List(const Polynome_List& orig) {
}

Polynome_List::~Polynome_List() {
}

void Polynome_List::fill(int degree) {
    
}

int Polynome_List::resolve(int unknown) {
        
}

