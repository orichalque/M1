/* 
 * File:   main.cpp
 * Author: E104607D
 *
 * Created on 28 septembre 2015, 16:13
 */

#include <cstdlib>
#include <vector>
#include <iostream>
#include "Polynome_Tab.h"
#include "Polynome_List.h"

using namespace std;

/*
 *    
 */
int main(int argc, char** argv) {
    Polynome_Tab *t = new Polynome_Tab(3);

    return 0;
}

